# Chạy trên KataBump

Nếu `weasyprint` lỗi khi cài trên host, đổi tên file:

```text
requirements.txt → requirements_full_local.txt
requirements_katabump.txt → requirements.txt
```

Startup command:

```bash
python app.py
```

Hoặc:

```bash
gunicorn app:app --bind 0.0.0.0:$PORT
```

`app.py` đã tự đọc `SERVER_PORT` hoặc `PORT`.
