CACH CHAY BAN QLSV v3

1) Giai nen file zip.
2) Mo VS Code tai thu muc vua giai nen.
3) Cai thu vien:
   pip install -r requirements.txt

4) Chay app chinh:
   python app.py

5) Mo trinh duyet:
   http://127.0.0.1:5000

Tai khoan mac dinh:
   admin
   admin123

Neu chay microservices, xem:
   README_KIEN_TRUC_HOAN_CHINH.md
   docs/12_CURL_TEST_CASES.md
