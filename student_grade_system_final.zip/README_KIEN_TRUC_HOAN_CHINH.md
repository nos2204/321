# QLSV v3 - Bản kiến trúc hoàn chỉnh theo ShopSphere 8 Lab

Bản này được làm lại để bám sát tài liệu thực hành Kiến Trúc Phần Mềm ShopSphere:

1. Requirements + ASR + Use Case
2. Layered Architecture
3. Layered CRUD Implementation
4. Microservices Decomposition
5. Microservice Implementation
6. API Gateway Pattern
7. Event-Driven Architecture
8. Deployment + ATAM

## Chạy app chính QLSV

```powershell
python app.py
```

Mặc định:

```text
admin / admin123
```

## Chạy microservices

Mở nhiều terminal:

```powershell
python microservices/auth_service/app.py
python microservices/student_service/app.py
python microservices/grade_service/app.py
python microservices/teacher_service/app.py
python microservices/enrollment_service/app.py
python microservices/timetable_service/app.py
python microservices/notification_service/app.py
python api_gateway/gateway.py
```

## Token test API Gateway

```text
Admin:   Bearer valid-admin-token
Teacher: Bearer valid-teacher-token
Student: Bearer valid-student-token
```

## Chạy EDA RabbitMQ

```powershell
docker run -d --hostname rabbitmq-host --name rabbitmq -p 5672:5672 -p 15672:15672 rabbitmq:3-management
python eda/rabbitmq_consumer.py
python eda/rabbitmq_producer.py
```

## Tài liệu cần nộp

Toàn bộ tài liệu nằm trong thư mục `docs/`.
