# Hệ thống QLSV - Bản làm lại theo tài liệu kiến trúc ShopSphere

Phiên bản này được tổ chức lại theo chuỗi lab trong tài liệu:

1. Requirements + ASR
2. Layered Architecture
3. Layered CRUD Implementation
4. Microservices Decomposition
5. Microservice scaffold
6. API Gateway scaffold
7. Event-Driven Architecture scaffold
8. Deployment + ATAM

## Cách chạy chính
```powershell
python app.py
```

## Tài khoản mặc định
```text
admin / admin123
```

## Kiến trúc chính
```text
app.py                                      # Entry point mỏng
presentation/routes/legacy_monolith.py      # Presentation Layer: routes/controllers
business/                                   # Business Logic Layer: services
persistence/                                # Persistence Layer: models/repositories
instance/student.db                         # Data Layer
```

## Điểm đã làm lại so với bản trước
- `app.py` đã được thu gọn thành entry point.
- Controller/route được đưa vào `presentation/routes/`.
- Bổ sung các service nghiệp vụ: `CatalogService`, `UserService`, `GradeService`, `EnrollmentService`.
- Bổ sung tài liệu kiến trúc trong thư mục `docs/`.
- Bổ sung scaffold microservices trong thư mục `microservices/`.
- Bổ sung API Gateway scaffold trong `api_gateway/`.
- Bổ sung EDA demo trong `eda/`.

## Mức độ tương thích tài liệu
- Lab 1: có tài liệu requirements/ASR.
- Lab 2: có kiến trúc phân lớp và component mapping.
- Lab 3: hệ thống chính chạy theo monolithic layered architecture.
- Lab 4-7: có thiết kế và scaffold để mở rộng.
- Lab 8: có deployment/ATAM documentation.

## Ghi chú quan trọng
Để giữ hệ thống chạy ổn ngay, một phần controller cũ vẫn còn trong `presentation/routes/legacy_monolith.py`. Đây là Presentation Layer. Các route mới hoặc khi phát triển tiếp nên chuyển dần query trực tiếp sang service/repository.
