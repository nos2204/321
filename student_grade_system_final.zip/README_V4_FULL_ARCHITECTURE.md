# QLSV V4 - Full Architecture Edition

## Chạy hệ thống web monolith phân lớp
```powershell
python app.py
```

## Chạy toàn bộ microservices + gateway + RabbitMQ
```powershell
docker compose -f docker-compose.full.yml up --build
```

## Token test API Gateway
```text
Admin:   Authorization: Bearer valid-admin-token
Teacher: Authorization: Bearer valid-teacher-token
Student: Authorization: Bearer valid-student-token
```

## Test nhanh
```powershell
pip install -r requirements_microservices.txt pytest
pytest
```

## Các cổng
- API Gateway: 5000
- Student Service: 5001
- Auth Service: 5002
- Grade Service: 5003
- Teacher Service: 5004
- Enrollment Service: 5005
- Timetable Service: 5006
- Notification Service: 5007
- RabbitMQ UI: 15672
