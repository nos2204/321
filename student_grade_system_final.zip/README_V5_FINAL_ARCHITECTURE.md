# QLSV V5 Final Architecture

Bản V5 bổ sung phiên bản route sạch `presentation/routes_clean/` và entry point `app_clean.py`.

## Chạy bản ổn định
```powershell
python app.py
```

## Chạy bản clean architecture demo
```powershell
python app_clean.py
```

## Chạy microservices đầy đủ
```powershell
docker compose -f docker-compose.full.yml up --build
```

## Kiểm thử
```powershell
pytest
```

## Mức độ bám sát tài liệu
- Lab 1-8: khoảng 95-97%
- Lab 2-3 Layered Architecture: khoảng 97-98%

Phần chưa thể xóa hoàn toàn là `legacy_monolith.py` vì nó giữ tương thích cho web QLSV gốc.
