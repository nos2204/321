# Student Grade System - V7 Strict Final

Bản V7 là bản nghiêm ngặt nhất theo tài liệu kiến trúc ShopSphere Lab 1-8.

## Chạy app chính

```powershell
python app.py
```

Mặc định chạy strict layered mode:

```text
app.py -> app_clean.py -> presentation/routes_clean -> business -> persistence -> database
```

## Kiểm thử kiến trúc

```powershell
pytest
```

## Chạy microservices full

```powershell
docker compose -f docker-compose.full.yml up --build
```

## Tài khoản mặc định

```text
admin / admin123
```

## Điểm khác V6

- Không còn fallback legacy trong `app.py`.
- Không còn `presentation/routes/legacy_monolith.py` trong source tree mặc định.
- Có test đảm bảo route sạch không dùng `.query` hoặc `db.session` trực tiếp.
