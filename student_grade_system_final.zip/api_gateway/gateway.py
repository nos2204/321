from flask import Flask, request, jsonify, make_response
import os
import requests

app = Flask(__name__)
SERVICE_URLS = {
    'auth': os.environ.get('AUTH_SERVICE_URL', 'http://127.0.0.1:5002'),
    'students': os.environ.get('STUDENT_SERVICE_URL', 'http://127.0.0.1:5001'),
    'grades': os.environ.get('GRADE_SERVICE_URL', 'http://127.0.0.1:5003'),
    'teachers': os.environ.get('TEACHER_SERVICE_URL', 'http://127.0.0.1:5004'),
    'enrollments': os.environ.get('ENROLLMENT_SERVICE_URL', 'http://127.0.0.1:5005'),
    'timetable': os.environ.get('TIMETABLE_SERVICE_URL', 'http://127.0.0.1:5006'),
    'notifications': os.environ.get('NOTIFICATION_SERVICE_URL', 'http://127.0.0.1:5007'),
}
VALID_TOKENS = {'valid-admin-token':'admin','valid-teacher-token':'teacher','valid-student-token':'student'}
ROUTE_PREFIX = {'auth':'auth','students':'students','grades':'grades','teachers':'teachers','enrollments':'enrollments','timetable':'timetable','notifications':'notifications'}
WRITE_ROLES = {
    'students': {'admin'}, 'teachers': {'admin'}, 'grades': {'admin','teacher'},
    'enrollments': {'admin','student'}, 'timetable': {'admin'}, 'notifications': {'admin','teacher'}
}

def validate_token():
    auth = request.headers.get('Authorization','')
    if not auth.startswith('Bearer '): return None, ('Thiếu Authorization header dạng Bearer token', 401)
    token = auth.replace('Bearer ','',1).strip(); role = VALID_TOKENS.get(token)
    if not role: return None, ('Token không hợp lệ hoặc đã hết hạn', 401)
    return role, None

def target_url(service_key, path=''):
    base = SERVICE_URLS[service_key].rstrip('/')
    url = f"{base}/api/{ROUTE_PREFIX[service_key]}"
    if path: url += '/' + path
    if request.query_string: url += '?' + request.query_string.decode()
    return url

def forward(service_key, path=''):
    try:
        resp = requests.request(
            method=request.method, url=target_url(service_key, path),
            headers={k: v for k, v in request.headers if k.lower() != 'host'},
            data=request.get_data(), timeout=5)
        out = make_response(resp.content, resp.status_code)
        if 'Content-Type' in resp.headers: out.headers['Content-Type'] = resp.headers['Content-Type']
        return out
    except requests.exceptions.RequestException as exc:
        return jsonify({'error':'Service Unavailable','service':service_key,'details':str(exc)}), 503

@app.get('/health')
def health():
    statuses = {}
    for key, base in SERVICE_URLS.items():
        try:
            r = requests.get(base.rstrip() + '/health', timeout=1.5)
            statuses[key] = {'ok': r.ok, 'status_code': r.status_code}
        except Exception as exc:
            statuses[key] = {'ok': False, 'error': str(exc)}
    return jsonify({'gateway':'ok','services':statuses}), 200

@app.route('/api/auth', defaults={'path':''}, methods=['GET','POST'])
@app.route('/api/auth/<path:path>', methods=['GET','POST'])
def route_auth(path): return forward('auth', path)

@app.route('/api/<service_key>', defaults={'path':''}, methods=['GET','POST','PUT','DELETE'])
@app.route('/api/<service_key>/<path:path>', methods=['GET','POST','PUT','DELETE'])
def route_service(service_key, path):
    if service_key not in SERVICE_URLS or service_key == 'auth': return jsonify({'error':'Không tìm thấy service'}), 404
    role, error = validate_token()
    if error: return jsonify({'error':'Unauthorized','details':error[0]}), error[1]
    if request.method in ['POST','PUT','DELETE'] and role not in WRITE_ROLES.get(service_key, set()):
        return jsonify({'error':'Forbidden','details':f'Role {role} không được phép {request.method} {service_key}'}), 403
    return forward(service_key, path)

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
