"""V7 strict final entry point.

This application starts ONLY the clean layered architecture:

    app.py -> app_clean.py -> presentation/routes_clean -> business -> persistence -> database

The old monolithic legacy router has been removed from the default source tree so
that the project can be assessed strictly against layered architecture rules.
"""
from __future__ import annotations

import os

from app_clean import app


if __name__ == '__main__':
    port = int(os.environ.get('SERVER_PORT') or os.environ.get('PORT') or 5000)
    debug = os.environ.get('FLASK_DEBUG', '0') == '1'
    app.run(host='0.0.0.0', port=port, debug=debug)
