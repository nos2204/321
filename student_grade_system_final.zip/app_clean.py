"""Experimental clean entry point without putting routes in app.py.

This file demonstrates the target 100% layered style:
- app.py/app_clean.py: bootstrapping only
- presentation/routes_clean: HTTP controllers only
- business: services/validation
- persistence: repositories/database access

Run:
    python app_clean.py
"""
from __future__ import annotations

import os
from flask import Flask
from config import Config
from persistence.database import db
from gateway import generate_csrf_token, validate_csrf
from presentation.routes_clean import CLEAN_BLUEPRINTS


def create_app() -> Flask:
    app = Flask(__name__, template_folder='presentation/templates', static_folder='presentation/static')
    app.config.from_object(Config)
    app.secret_key = app.config['SECRET_KEY']
    db.init_app(app)

    @app.context_processor
    def inject_globals():
        from datetime import datetime
        return {'csrf_token': generate_csrf_token, 'now': datetime.utcnow}

    with app.app_context():
        db.create_all()

    for bp in CLEAN_BLUEPRINTS:
        app.register_blueprint(bp)

    return app


app = create_app()

if __name__ == '__main__':
    port = int(os.environ.get('SERVER_PORT') or os.environ.get('PORT') or 5000)
    app.run(host='0.0.0.0', port=port, debug=os.environ.get('FLASK_DEBUG') == '1')
