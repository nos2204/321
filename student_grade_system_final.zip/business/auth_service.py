"""Business Logic Layer: authentication use cases."""
from __future__ import annotations

from dataclasses import dataclass
from persistence.repositories import UserRepository
from gateway import check_brute_force, record_failed_login, record_success_login


@dataclass
class AuthResult:
    success: bool
    user: object | None = None
    message: str = ''
    locked: bool = False


class AuthService:
    """Xử lý nghiệp vụ đăng nhập, khóa tạm thời và thông báo lỗi.

    Presentation Layer chỉ gửi username/password vào đây. Service sẽ gọi Repository
    để lấy User và áp dụng quy tắc bảo mật.
    """

    def __init__(self, user_repo=None):
        self.user_repo = user_repo or UserRepository()

    def authenticate(self, username: str, password: str) -> AuthResult:
        user = self.user_repo.find_by_username(username)

        locked, wait = check_brute_force(user)
        if locked:
            return AuthResult(False, user=user, message=f'Tài khoản bị khoá tạm thời. Thử lại sau {wait}.', locked=True)

        if user and user.check_password(password):
            record_success_login(user)
            return AuthResult(True, user=user, message='Đăng nhập thành công!')

        if user:
            record_failed_login(user)

        return AuthResult(False, user=user, message='Tài khoản hoặc mật khẩu không chính xác!')
