"""Business Logic Layer - dịch vụ danh mục dùng chung.

Controller không cần biết cách query Department/Class/Subject/Teacher/Semester.
Nó chỉ gọi CatalogService để lấy dữ liệu đã được sắp xếp/kiểm tra.
"""
from persistence.repositories import (
    DepartmentRepository, ClassRepository, SubjectRepository,
    TeacherRepository, SemesterRepository, CourseSectionRepository,
)


class CatalogService:
    def __init__(self):
        self.departments = DepartmentRepository()
        self.classes = ClassRepository()
        self.subjects = SubjectRepository()
        self.teachers = TeacherRepository()
        self.semesters = SemesterRepository()
        self.sections = CourseSectionRepository()

    def form_options(self):
        return {
            'departments': self.departments.ordered(),
            'classes': self.classes.ordered(),
            'subjects': self.subjects.ordered(),
            'teachers': self.teachers.ordered(),
            'semesters': self.semesters.ordered(),
            'sections': self.sections.ordered(),
        }

    def current_semester(self):
        return self.semesters.current()
