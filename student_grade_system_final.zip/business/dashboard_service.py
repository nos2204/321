"""Business Logic Layer: dashboard statistics."""
from persistence.repositories import (
    StudentRepository,
    SubjectRepository,
    DepartmentRepository,
    SemesterRepository,
    UserRepository,
    ClassRepository,
    TeacherRepository,
    CourseSectionRepository,
    EnrollmentRepository,
)


class DashboardService:
    def __init__(self):
        self.students = StudentRepository()
        self.subjects = SubjectRepository()
        self.departments = DepartmentRepository()
        self.semesters = SemesterRepository()
        self.users = UserRepository()
        self.classes = ClassRepository()
        self.teachers = TeacherRepository()
        self.sections = CourseSectionRepository()
        self.enrollments = EnrollmentRepository()

    def get_stats(self):
        current_sem = self.semesters.current()
        return dict(
            total=self.students.count(),
            gioi=self.students.count_by_rank('Giỏi'),
            kha=self.students.count_by_rank('Khá'),
            tb=self.students.count_by_rank('Trung bình'),
            yeu=self.students.count_by_rank('Yếu'),
            nam=self.students.count_by_gender('Nam'),
            nu=self.students.count_by_gender('Nữ'),
            top5=self.students.top_by_gpa(5),
            current_sem=current_sem,
            total_subjects=self.subjects.count(),
            total_departments=self.departments.count(),
            total_semesters=self.semesters.count(),
            total_users=self.users.count(),
            total_classes=self.classes.count(),
            total_teachers=self.teachers.count(),
            total_sections=self.sections.count(),
            total_enrollments=self.enrollments.registered_count(),
            no_account=self.students.count_without_account(),
            no_grade=self.students.count_without_grade(),
        )
