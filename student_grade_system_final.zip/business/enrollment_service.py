"""Business Logic Layer - đăng ký học phần."""
from persistence.models import EnrollmentModel, db
from persistence.repositories import EnrollmentRepository, CourseSectionRepository, AuditLogRepository


class EnrollmentService:
    def __init__(self):
        self.enrollments = EnrollmentRepository()
        self.sections = CourseSectionRepository()
        self.audit = AuditLogRepository()

    def register(self, student_id, section_id, actor='system'):
        section = self.sections.get_or_404(section_id)
        if section.status != 'open':
            raise ValueError('Lớp học phần không còn mở đăng ký.')
        if section.is_full:
            raise ValueError('Lớp học phần đã đủ số lượng.')
        old = self.enrollments.find_registered(student_id, section_id)
        if old:
            raise ValueError('Bạn đã đăng ký lớp học phần này.')
        enrollment = EnrollmentModel(student_id=student_id, section_id=section_id, status='registered')
        db.session.add(enrollment)
        self.audit.write(actor, 'REGISTER_SECTION', f'section={section_id}', f'student={student_id}', commit=False)
        db.session.commit()
        return enrollment

    def cancel(self, enrollment_id, actor='system'):
        enrollment = self.enrollments.get_or_404(enrollment_id)
        enrollment.status = 'cancelled'
        self.audit.write(actor, 'CANCEL_ENROLLMENT', f'enrollment={enrollment_id}', commit=False)
        db.session.commit()
        return enrollment


# ===== V6: Clean route helpers =====
def _register_current_student(self, section_id):
    from flask import session
    student_id = session.get('linked_student_id')
    if not student_id:
        raise ValueError('Tài khoản chưa liên kết sinh viên.')
    enrollment = self.register(student_id, section_id, actor=session.get('username','student'))
    return {'id': enrollment.id, 'message': 'registered'}

def _cancel_current_student(self, enrollment_id):
    from flask import session
    enrollment = self.cancel(enrollment_id, actor=session.get('username','student'))
    return {'id': enrollment.id, 'message': 'cancelled'}

EnrollmentService.register_current_student = _register_current_student
EnrollmentService.cancel_current_student = _cancel_current_student
