"""Business Logic Layer - nhập điểm, tính điểm, khóa điểm."""
from datetime import datetime
from persistence.models import GradeModel, db
from persistence.repositories import GradeRepository, StudentRepository, AuditLogRepository


class GradeService:
    def __init__(self):
        self.grades = GradeRepository()
        self.students = StudentRepository()
        self.audit = AuditLogRepository()

    def upsert_grade(self, student_id, subject_id, semester_id, progress_grade, exam_grade, actor='system'):
        if not (0 <= float(progress_grade) <= 10 and 0 <= float(exam_grade) <= 10):
            raise ValueError('Điểm phải nằm trong khoảng 0 đến 10.')
        grade = self.grades.find_student_subject_semester(student_id, subject_id, semester_id)
        if not grade:
            grade = GradeModel(student_id=student_id, subject_id=subject_id, semester_id=semester_id)
            db.session.add(grade)
        grade.progress_grade = float(progress_grade)
        grade.exam_grade = float(exam_grade)
        grade.updated_at = datetime.utcnow()
        self.audit.write(actor, 'UPSERT_GRADE', f'student={student_id}', f'subject={subject_id}, semester={semester_id}', commit=False)
        db.session.commit()
        return grade

    def calculate_gpa(self, student_id, semester_id=None):
        q = GradeModel.query.filter_by(student_id=student_id)
        if semester_id:
            q = q.filter_by(semester_id=semester_id)
        grades = q.all()
        total_points = 0
        total_credits = 0
        for g in grades:
            credits = g.subject.credits if g.subject else 0
            total_points += g.grade_point_4 * credits
            total_credits += credits
        return round(total_points / total_credits, 2) if total_credits else 0


# ===== V6: Clean layered API helpers =====
def _get_student_grades(self, student_id):
    grades = GradeModel.query.filter_by(student_id=student_id).all()
    return [{
        'id': g.id,
        'student_id': g.student_id,
        'subject': g.subject.subject_name if g.subject else '',
        'progress_grade': g.progress_grade,
        'exam_grade': g.exam_grade,
        'final_grade': g.final_grade,
    } for g in grades]

def _save_grade(self, student_id, payload):
    subject_id = int(payload.get('subject_id'))
    semester_id = int(payload.get('semester_id')) if payload.get('semester_id') else None
    progress = float(payload.get('progress_grade', 0))
    exam = float(payload.get('exam_grade', 0))
    grade = self.upsert_grade(student_id, subject_id, semester_id, progress, exam)
    return {'id': grade.id, 'message': 'saved'}

GradeService.get_student_grades = _get_student_grades
GradeService.save_grade = _save_grade
