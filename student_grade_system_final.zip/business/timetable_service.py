"""Business Logic Layer: timetable parsing and view model building."""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta


class TimetableService:
    @staticmethod
    def parse_schedule_text(schedule_text):
        if not schedule_text:
            return []

        text = schedule_text.strip()
        day_map = {
            '2': 0, 'hai': 0, 'thứ 2': 0, 'thu 2': 0, 't2': 0,
            '3': 1, 'ba': 1, 'thứ 3': 1, 'thu 3': 1, 't3': 1,
            '4': 2, 'tư': 2, 'tu': 2, 'thứ 4': 2, 'thu 4': 2, 't4': 2,
            '5': 3, 'năm': 3, 'nam': 3, 'thứ 5': 3, 'thu 5': 3, 't5': 3,
            '6': 4, 'sáu': 4, 'sau': 4, 'thứ 6': 4, 'thu 6': 4, 't6': 4,
            '7': 5, 'bảy': 5, 'bay': 5, 'thứ 7': 5, 'thu 7': 5, 't7': 5,
            'cn': 6, 'chủ nhật': 6, 'chu nhat': 6, 'sunday': 6,
        }

        lower = text.lower()
        day_index = None
        for key, value in day_map.items():
            if re.search(r'(^|\W)' + re.escape(key) + r'(\W|$)', lower):
                day_index = value
                break

        time_matches = re.findall(r'(\d{1,2}:\d{2})\s*[-–]\s*(\d{1,2}:\d{2})', text)
        if day_index is None or not time_matches:
            return []

        results = []
        for start_time, end_time in time_matches:
            results.append({
                'day_index': day_index,
                'start_time': start_time,
                'end_time': end_time,
            })
        return results

    @staticmethod
    def time_to_minutes(time_text):
        hour, minute = [int(x) for x in time_text.split(':')]
        return hour * 60 + minute

    @staticmethod
    def get_week_start(any_date=None):
        any_date = any_date or date.today()
        return any_date - timedelta(days=any_date.weekday())

    @classmethod
    def build_week_days(cls, base_date=None):
        start = cls.get_week_start(base_date)
        labels = ['Thứ 2', 'Thứ 3', 'Thứ 4', 'Thứ 5', 'Thứ 6', 'Thứ 7', 'Chủ nhật']
        return [{'date': start + timedelta(days=i), 'label': labels[i]} for i in range(7)]

    @classmethod
    def build_timetable_events(cls, sections):
        colors = ['primary', 'orange', 'purple', 'success', 'danger', 'info', 'secondary']
        events = []
        for index, section in enumerate(sections):
            schedule_items = cls.parse_schedule_text(section.schedule or '')
            for item in schedule_items:
                start_minutes = cls.time_to_minutes(item['start_time'])
                end_minutes = cls.time_to_minutes(item['end_time'])
                duration = max(45, end_minutes - start_minutes)
                events.append({
                    'id': section.id,
                    'section_code': section.section_code,
                    'subject_name': section.subject.subject_name if section.subject else 'Không rõ môn',
                    'teacher_name': section.teacher.full_name if section.teacher else 'Chưa phân công',
                    'room': section.room or 'Chưa có phòng',
                    'schedule_text': section.schedule or '',
                    'day_index': item['day_index'],
                    'start_time': item['start_time'],
                    'end_time': item['end_time'],
                    'start_minutes': start_minutes,
                    'duration_minutes': duration,
                    'color_class': colors[index % len(colors)],
                })
        return events

    @staticmethod
    def build_event_students(sections):
        data = {}
        for section in sections:
            students = []
            for enrollment in section.enrollments:
                if enrollment.status == 'registered' and enrollment.student:
                    students.append(enrollment.student)
            data[section.id] = students
        return data


# ===== V6: Clean route context builders =====
def _safe_sections_for_student():
    from flask import session
    from persistence.models import CourseSectionModel, EnrollmentModel
    sid = session.get('linked_student_id')
    if not sid:
        return []
    enrollments = EnrollmentModel.query.filter_by(student_id=sid, status='registered').all()
    return [e.section for e in enrollments if e.section]

def _safe_sections_for_teacher():
    from flask import session
    from persistence.models import CourseSectionModel
    tid = session.get('linked_teacher_id')
    if not tid:
        return []
    return CourseSectionModel.query.filter_by(teacher_id=tid).all()

def _safe_all_sections():
    from persistence.models import CourseSectionModel
    return CourseSectionModel.query.all()

def _context_from_sections(self, sections, title, note, ttype):
    return {
        'page_title': title,
        'page_note': note,
        'timetable_type': ttype,
        'week_days': self.build_week_days(),
        'events': self.build_timetable_events(sections),
        'event_id_to_students': self.build_event_students(sections),
    }

def _get_student_timetable_context(self):
    return _context_from_sections(self, _safe_sections_for_student(), 'Thời khóa biểu sinh viên', 'Lịch các lớp học phần đã đăng ký', 'student')

def _get_teacher_timetable_context(self):
    return _context_from_sections(self, _safe_sections_for_teacher(), 'Thời khóa biểu giảng viên', 'Lịch các lớp học phần được phân công', 'teacher')

def _get_admin_timetable_context(self):
    return _context_from_sections(self, _safe_all_sections(), 'Thời khóa biểu toàn hệ thống', 'Tất cả lớp học phần', 'admin')

TimetableService.get_student_timetable_context = _get_student_timetable_context
TimetableService.get_teacher_timetable_context = _get_teacher_timetable_context
TimetableService.get_admin_timetable_context = _get_admin_timetable_context
