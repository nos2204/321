"""Business Logic Layer - quản lý tài khoản người dùng."""
from persistence.models import UserModel, db
from persistence.repositories import UserRepository, AuditLogRepository


class UserService:
    def __init__(self):
        self.users = UserRepository()
        self.audit = AuditLogRepository()

    def create_user(self, username, password, role='student', student_id=None, teacher_id=None, actor='system'):
        username = (username or '').strip()
        if not username:
            raise ValueError('Tên đăng nhập không được rỗng.')
        if self.users.find_by_username(username):
            raise ValueError('Tên đăng nhập đã tồn tại.')
        user = UserModel(username=username, role=role, student_id=student_id, teacher_id=teacher_id)
        user.set_password(password or '123456')
        db.session.add(user)
        self.audit.write(actor, 'CREATE_USER', username, f'role={role}', commit=False)
        db.session.commit()
        return user

    def reset_password(self, user_id, new_password='123456', actor='system'):
        user = self.users.get_or_404(user_id)
        user.set_password(new_password)
        self.audit.write(actor, 'RESET_PASSWORD', user.username, commit=False)
        db.session.commit()
        return user

    def delete_user(self, user_id, actor='system'):
        user = self.users.get_or_404(user_id)
        username = user.username
        db.session.delete(user)
        self.audit.write(actor, 'DELETE_USER', username, commit=False)
        db.session.commit()
        return username
