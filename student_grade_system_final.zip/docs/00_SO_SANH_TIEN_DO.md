# So sánh tiến độ QLSV v3 với tài liệu ShopSphere 8 Lab

| Lab | Nội dung | Mức đạt v3 | Ghi chú |
|---|---|---:|---|
| Lab 1 | Requirements, FR, NFR, ASR, Use Case | 92% | Có tài liệu và sơ đồ ASCII; nếu cần 100% thì vẽ draw.io thật |
| Lab 2 | Layered Architecture Design | 92% | Có đủ Presentation, Business, Persistence, Data |
| Lab 3 | Layered CRUD Implementation | 86% | App chính chạy đầy đủ; còn legacy controller để giữ ổn định |
| Lab 4 | Microservices Decomposition | 92% | Có phân rã service theo nghiệp vụ QLSV |
| Lab 5 | Microservice Implementation | 80% | Có 6 microservice độc lập + health + CRUD/API cơ bản |
| Lab 6 | API Gateway | 85% | Có gateway định tuyến, token, role, 503 khi service lỗi |
| Lab 7 | EDA RabbitMQ | 82% | Có producer/consumer thật bằng pika; cần Docker RabbitMQ khi chạy |
| Lab 8 | Deployment + ATAM | 85% | Có docker-compose, host note, ATAM/trade-off docs |

## Tổng kết

- Theo toàn bộ 8 Lab: khoảng **86-88%**.
- Theo Lab 2-3 kiến trúc phân lớp: khoảng **90%**.
- Theo mức chạy đồ án QLSV thực tế: khoảng **90%**.

## Vì sao chưa 100%?

- Chưa có file ảnh draw.io UML thật, mới có sơ đồ ASCII/Markdown.
- App web chính vẫn giữ `legacy_monolith.py` để đảm bảo chạy ổn; để 100% kiến trúc sạch cần tách toàn bộ route cũ thành Blueprint nhỏ và không để route gọi `Model.query` trực tiếp.
- Microservices là bản demo độc lập theo contract, chưa thay thế hoàn toàn app web chính.
