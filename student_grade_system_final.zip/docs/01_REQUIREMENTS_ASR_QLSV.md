# Lab 1 - Phân tích yêu cầu & ASR cho Hệ thống QLSV

## Actor
- **Administrator**: quản lý sinh viên, giảng viên, môn học, lớp, học kỳ, tài khoản, nhật ký.
- **Teacher**: xem lớp giảng dạy, nhập điểm học phần, xem thời khóa biểu giảng viên.
- **Student**: đăng nhập, xem hồ sơ, đăng ký học phần, xem điểm và thời khóa biểu.
- **Hosting/Database System**: lưu trữ dữ liệu, phục vụ triển khai local/KataBump.

## Functional Requirements
| Mã | Yêu cầu chức năng | Actor |
|---|---|---|
| FR-01 | Đăng nhập, đăng xuất, đổi mật khẩu, phân quyền | Admin, Teacher, Student |
| FR-02 | Quản lý hồ sơ sinh viên và giảng viên | Admin |
| FR-03 | Quản lý danh mục môn học, khoa/ngành, lớp, học kỳ | Admin |
| FR-04 | Đăng ký học phần, hủy đăng ký học phần | Student |
| FR-05 | Nhập điểm, tính GPA, xếp loại học lực | Admin, Teacher |
| FR-06 | Hiển thị thời khóa biểu riêng cho sinh viên và giảng viên | Student, Teacher |
| FR-07 | Import/Export dữ liệu và ghi nhật ký thao tác | Admin |

## Non-Functional Requirements
| Mã | Thuộc tính | Mô tả | Ngưỡng |
|---|---|---|---|
| NFR-01 | Hiệu năng | Trang chính và danh sách phản hồi nhanh | < 2 giây với dữ liệu demo |
| NFR-02 | Bảo mật | Mật khẩu băm, session/JWT, phân quyền route | 100% route nhạy cảm có decorator |
| NFR-03 | Bảo trì | Tách Presentation/Business/Persistence | Controller không query DB trực tiếp ở phiên bản mục tiêu |
| NFR-04 | Triển khai | Chạy local, VS Code, KataBump | Đọc PORT/SERVER_PORT |
| NFR-05 | Khả năng mở rộng | Có thiết kế microservice/API Gateway mở rộng | Có service contract và scaffold |

## ASR
- **ASR-01: Bảo mật phân quyền**: mọi thao tác điểm/tài khoản/danh mục phải kiểm tra role.
- **ASR-02: Bảo trì dễ mở rộng**: bắt buộc dùng luồng `Controller → Service → Repository → Database`.
- **ASR-03: Tách module học vụ**: sinh viên, điểm, đăng ký, thời khóa biểu phải có service riêng để sau này tách microservice.
