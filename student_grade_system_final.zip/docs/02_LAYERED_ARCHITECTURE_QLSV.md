# Lab 2 - Thiết kế kiến trúc phân lớp QLSV

## Logical View
```text
Client Browser / Mobile
        ↓ HTTP
Presentation Layer
- app.py chỉ là entry point
- presentation/routes/legacy_monolith.py giữ route/controller
- presentation/templates render UI
        ↓ gọi Service
Business Logic Layer
- AuthService
- StudentService
- DashboardService
- TimetableService
- CatalogService
- UserService
- GradeService
- EnrollmentService
        ↓ gọi Repository
Persistence Layer
- persistence/models.py
- persistence/repositories.py
        ↓ ORM
Data Layer
- SQLite/MySQL database
```

## Nguyên tắc phụ thuộc
- Presentation được phép gọi Business Service.
- Business Service được phép gọi Repository.
- Repository được phép gọi SQLAlchemy Model/db.
- Template không chứa logic nghiệp vụ.
- Route không nên chứa `Model.query` hoặc `db.session` trong phiên bản mục tiêu.

## Component Mapping
| Layer | Component QLSV | Trách nhiệm |
|---|---|---|
| Presentation | `presentation/routes/legacy_monolith.py` | Nhận request, gọi service, render template |
| Business | `business/*.py` | Validation, nghiệp vụ đăng ký/điểm/GPA/lịch |
| Persistence | `persistence/repositories.py` | CRUD và query database |
| Data | `instance/student.db` | Lưu trữ vật lý |

## Luồng ví dụ: đăng ký học phần
```text
Student Browser
  → POST /enrollments/register/<section_id>
  → Enrollment Controller
  → EnrollmentService.register(student_id, section_id)
  → EnrollmentRepository + CourseSectionRepository
  → SQLite/MySQL
  → flash message + redirect
```
