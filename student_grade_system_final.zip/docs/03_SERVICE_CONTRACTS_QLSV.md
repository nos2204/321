# Lab 4 - Service Contracts cho QLSV

## Auth/User Service
| Endpoint | Method | Mô tả |
|---|---|---|
| `/login` | GET/POST | Đăng nhập |
| `/logout` | GET | Đăng xuất |
| `/change_password` | GET/POST | Đổi mật khẩu |
| `/users` | GET | Quản lý tài khoản |

## Student Service
| Endpoint | Method | Mô tả |
|---|---|---|
| `/students` | GET | Danh sách/tìm kiếm sinh viên |
| `/students/add` | GET/POST | Thêm sinh viên |
| `/students/<id>` | GET | Chi tiết sinh viên |
| `/students/<id>/edit` | GET/POST | Sửa sinh viên |
| `/students/<id>/delete` | POST | Xóa sinh viên |

## Grade Service
| Endpoint | Method | Mô tả |
|---|---|---|
| `/students/<id>/grades` | GET/POST | Xem/nhập điểm |
| `/grades/import` | GET/POST | Import điểm |
| `/teacher/sections/<id>/grades` | GET/POST | Giảng viên nhập điểm học phần |

## Enrollment Service
| Endpoint | Method | Mô tả |
|---|---|---|
| `/enrollments` | GET | Danh sách lớp có thể đăng ký |
| `/enrollments/register/<section_id>` | POST | Đăng ký lớp học phần |
| `/enrollments/cancel/<enrollment_id>` | POST | Hủy đăng ký |

## Timetable Service
| Endpoint | Method | Mô tả |
|---|---|---|
| `/student/timetable` | GET | TKB sinh viên |
| `/teacher/timetable` | GET | TKB giảng viên |
| `/admin/timetable` | GET | TKB toàn hệ thống |
