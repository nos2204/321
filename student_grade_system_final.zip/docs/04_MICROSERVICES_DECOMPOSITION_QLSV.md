# Lab 4-5 - Phân rã microservices cho QLSV

## Đề xuất service
| Năng lực nghiệp vụ | Microservice | Dữ liệu sở hữu |
|---|---|---|
| Xác thực & tài khoản | Auth/User Service | users, roles, credentials |
| Hồ sơ sinh viên | Student Service | students, classes, departments |
| Giảng viên | Teacher Service | teachers, teaching sections |
| Học phần & đăng ký | Enrollment Service | course_sections, enrollments |
| Điểm | Grade Service | grades, GPA calculation |
| Lịch học | Timetable Service | schedule projection |
| Thông báo | Notification Service | notification events |

## Quy tắc ranh giới
- Grade Service không truy cập trực tiếp database của Student Service khi đã tách microservice.
- Enrollment Service cần thông tin sinh viên/lớp học phần qua API contract.
- Notification Service nhận event, không chặn luồng nhập điểm/đăng ký.

## Trạng thái hiện tại
- Bản chạy chính vẫn là monolithic layered để dễ nộp/chạy.
- Thư mục `microservices/` và `api_gateway/` là scaffold để chứng minh thiết kế Lab 4-7.
