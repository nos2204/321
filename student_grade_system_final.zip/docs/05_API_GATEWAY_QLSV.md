# Lab 6 - API Gateway Pattern cho QLSV

Gateway là điểm vào duy nhất nếu tách service:

```text
Client
  ↓
API Gateway (:5000)
  - kiểm tra token
  - kiểm tra role admin/teacher/student
  - định tuyến
  ↓
Student Service (:5101)
Grade Service (:5102)
Notification Service / EDA
```

## Token mô phỏng
- `Bearer valid-admin-token`
- `Bearer valid-teacher-token`
- `Bearer valid-student-token`

## Kiểm thử mẫu
```bash
python microservices/student_service/app.py
python microservices/grade_service/app.py
python api_gateway/gateway.py
curl -H "Authorization: Bearer valid-admin-token" http://127.0.0.1:5000/api/students
```
