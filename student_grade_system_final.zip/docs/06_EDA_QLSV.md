# Lab 7 - Event Driven Architecture cho QLSV

## Event đề xuất
| Event | Producer | Consumer |
|---|---|---|
| `StudentCreatedEvent` | Student Service | Notification Service |
| `GradeUpdatedEvent` | Grade Service | Notification Service |
| `EnrollmentRegisteredEvent` | Enrollment Service | Notification Service |

## Lợi ích
- Khi Notification Service lỗi, nhập điểm/đăng ký học phần vẫn hoạt động.
- Event có thể tích lũy trong queue và xử lý sau.
- Giảm phụ thuộc trực tiếp giữa service nghiệp vụ và thông báo.

## Scaffold
Thư mục `eda/` có ví dụ producer/consumer đơn giản. Có thể thay bằng RabbitMQ/pika nếu triển khai thật.
