# Lab 8 - Deployment & ATAM cho QLSV

## Deployment View
```text
Local/VS Code hoặc KataBump
  ├── Flask Web App
  ├── SQLite instance/student.db hoặc MySQL
  ├── Static files CSS/JS
  └── Optional API Gateway + Microservices scaffold
```

## Scenarios ATAM
| Scenario | Kiến trúc đáp ứng | Trade-off |
|---|---|---|
| Chạy đơn giản trên VS Code | Monolithic layered | Dễ chạy nhưng scale thấp |
| Bảo trì chức năng điểm | Service/Repository riêng | Cần viết nhiều file hơn |
| Tách microservice sau này | Có contract + scaffold | Triển khai phức tạp hơn |
| Host KataBump | Đọc PORT/SERVER_PORT | SQLite có rủi ro mất dữ liệu nếu reset |

## Kết luận
Phiên bản hiện tại ưu tiên chạy ổn và đúng phân lớp. Microservices/API Gateway/EDA đã có cấu trúc mẫu để đáp ứng phần thiết kế của tài liệu.
