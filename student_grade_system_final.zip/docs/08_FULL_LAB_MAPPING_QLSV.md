# Mapping QLSV với tài liệu ShopSphere 8 Lab

Tài liệu gốc ShopSphere có 8 Lab: Requirements/ASR, Layered Architecture, CRUD Layered, Microservices Decomposition, Microservice Implementation, API Gateway, Event-Driven Architecture, Deployment/ATAM.

Bản QLSV v3 này ánh xạ như sau:

| Lab | Yêu cầu trong tài liệu | Hiện thực trong QLSV v3 |
|---|---|---|
| Lab 1 | Actor, FR, NFR, ASR, Use Case | `docs/01_REQUIREMENTS_ASR_QLSV.md`, Actor Admin/Giảng viên/Sinh viên, Use Case QLSV |
| Lab 2 | Presentation, Business, Persistence, Data Layer | `presentation/`, `business/`, `persistence/`, `instance/student.db` |
| Lab 3 | CRUD qua Controller -> Service -> Repository | App chính chạy được, service/repository cho module chính, legacy route được giữ để đảm bảo chạy ổn |
| Lab 4 | Phân rã Microservices theo năng lực nghiệp vụ | `docs/04_MICROSERVICES_DECOMPOSITION_QLSV.md`, thư mục `microservices/` |
| Lab 5 | Microservice độc lập | `auth_service`, `student_service`, `grade_service`, `teacher_service`, `enrollment_service`, `timetable_service` |
| Lab 6 | API Gateway Pattern | `api_gateway/gateway.py` định tuyến, kiểm tra token, xử lý service offline |
| Lab 7 | Event-Driven Architecture | `eda/rabbitmq_producer.py`, `eda/rabbitmq_consumer.py`, queue `qlsv_events` |
| Lab 8 | Deployment & ATAM | `docs/07_DEPLOYMENT_ATAM_QLSV.md`, `docker-compose.microservices.yml`, `HOST_KATABUMP.md` |

## Kiến trúc tổng thể

```text
Client Web/Mobile
      |
      v
API Gateway :5000
      |
      +--> Auth Service :5002
      +--> Student Service :5001
      +--> Grade Service :5003
      +--> Teacher Service :5004
      +--> Enrollment Service :5005
      +--> Timetable Service :5006
      +--> Notification Service :5007

Event flow:
Enrollment/Grade Event -> RabbitMQ queue qlsv_events -> Notification Consumer
```

## Luồng Layered trong app chính

```text
presentation/routes/legacy_monolith.py
        |
        v
business/*_service.py
        |
        v
persistence/repositories.py + persistence/models.py
        |
        v
instance/student.db
```

## Ghi chú trung thực

- Để giữ hệ thống QLSV web chạy ổn, app chính vẫn giữ `legacy_monolith.py`.
- Các microservice được triển khai độc lập theo contract và có thể chạy/test riêng.
- RabbitMQ EDA đã có producer/consumer thật bằng `pika`; cần Docker RabbitMQ để chạy.
