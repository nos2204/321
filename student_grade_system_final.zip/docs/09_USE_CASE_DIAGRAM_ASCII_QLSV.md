# Use Case Diagram ASCII - QLSV System

```text
┌──────────────────────────────────────────────────────────────────────┐
│                    QLSV Student Grade System                          │
│                                                                      │
│   ┌──────────────┐       ┌─────────────────┐      ┌───────────────┐ │
│   │ Đăng nhập    │       │ Quản lý SV       │      │ Quản lý GV     │ │
│   └──────────────┘       └─────────────────┘      └───────────────┘ │
│                                                                      │
│   ┌────────────────┐     ┌─────────────────┐      ┌───────────────┐ │
│   │ Quản lý môn/lớp│     │ Đăng ký học phần │      │ Nhập điểm HP   │ │
│   └────────────────┘     └─────────────────┘      └───────────────┘ │
│                                                                      │
│   ┌────────────────┐     ┌─────────────────┐      ┌───────────────┐ │
│   │ Xem TKB SV     │     │ Xem TKB GV       │      │ Xuất Excel     │ │
│   └────────────────┘     └─────────────────┘      └───────────────┘ │
│                                                                      │
│   Use Case Đăng ký học phần <<include>> Kiểm tra lớp học phần          │
│   Use Case Nhập điểm HP <<include>> Tính GPA và xếp loại               │
│   Use Case Đăng nhập <<extend>> Khóa tài khoản khi sai nhiều lần        │
└──────────────────────────────────────────────────────────────────────┘

👤 Admin      --> Quản lý SV/GV/Môn/Lớp/Tài khoản/Nhật ký/Xuất Excel
👤 Giảng viên --> Xem lớp dạy, nhập điểm, xem TKB giảng viên
👤 Sinh viên  --> Đăng ký học phần, xem điểm, xem TKB, xem hồ sơ
🔗 Email/Notification Service --> Nhận event và gửi thông báo
```
