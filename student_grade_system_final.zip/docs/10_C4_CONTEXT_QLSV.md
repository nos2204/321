# C4 Model Level 1 - System Context QLSV

```text
┌────────────────────────────── Người dùng ──────────────────────────────┐
│  Admin                  Giảng viên                  Sinh viên           │
│  Quản lý hệ thống       Nhập điểm, xem lớp          Đăng ký HP, xem TKB │
└───────────────┬──────────────────────┬──────────────────────┬──────────┘
                │                      │                      │
                v                      v                      v
┌─────────────────────────────────────────────────────────────────────────┐
│                  [System] QLSV Student Grade System                     │
│                                                                         │
│  - Quản lý sinh viên, giảng viên, môn học, lớp học phần                  │
│  - Đăng ký học phần, nhập điểm, tính GPA                                 │
│  - Quản lý thời khóa biểu                                                │
│  - Import/Export Excel                                                   │
│  - Phân quyền admin/teacher/student                                      │
└──────────────────────────────────┬──────────────────────────────────────┘
                                   │
                                   v
┌──────────────────────────── Hệ thống ngoài ─────────────────────────────┐
│ SQLite/MySQL Database     RabbitMQ Broker      Notification/Email        │
└─────────────────────────────────────────────────────────────────────────┘
```
