# ATAM và Trade-offs - QLSV

## Quality Attribute Scenarios

| Mã | Thuộc tính | Scenario | Đánh giá |
|---|---|---|---|
| QA-01 | Performance | Tìm sinh viên/nhập điểm phản hồi < 2 giây | Đạt với SQLite demo; cần index khi dữ liệu lớn |
| QA-02 | Security | Mật khẩu hash, phân quyền role, token gateway | Đạt mức demo; production cần HTTPS/OAuth2 thật |
| QA-03 | Scalability | Tách Student/Grade/Enrollment/Timetable service | Có scaffold microservices; cần container orchestration để scale thật |
| QA-04 | Availability | Service lỗi không làm sập toàn bộ gateway | Gateway trả 503 nếu backend offline |
| QA-05 | Modifiability | Thêm module mới không sửa nhiều tầng khác | Layered + service/repository giúp dễ mở rộng |

## Trade-offs

| Quyết định | Lợi ích | Đánh đổi |
|---|---|---|
| Giữ app chính monolithic layered | Dễ chạy VS Code/KataBump | Chưa scale độc lập từng module |
| Thêm microservices demo | Giống tài liệu Lab 4-6 | Phức tạp hơn khi chạy nhiều terminal |
| RabbitMQ cho notification | Không mất sự kiện khi consumer tắt | Cần Docker/RabbitMQ |
| SQLite cho demo | Dễ chạy ngay | Không phù hợp tải lớn/production |
