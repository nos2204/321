# Test Cases cURL cho Microservices và API Gateway

## 1. Chạy service

```powershell
python microservices/auth_service/app.py
python microservices/student_service/app.py
python microservices/grade_service/app.py
python microservices/teacher_service/app.py
python microservices/enrollment_service/app.py
python microservices/timetable_service/app.py
python microservices/notification_service/app.py
python api_gateway/gateway.py
```

## 2. Login qua Auth Service

```bash
curl -X POST http://127.0.0.1:5002/api/auth/login -H "Content-Type: application/json" -d '{"username":"admin","password":"admin123"}'
```

## 3. Gọi qua API Gateway

```bash
curl -H "Authorization: Bearer valid-admin-token" http://127.0.0.1:5000/api/students
curl -H "Authorization: Bearer valid-admin-token" http://127.0.0.1:5000/api/grades
curl -H "Authorization: Bearer valid-admin-token" http://127.0.0.1:5000/api/teachers
curl -H "Authorization: Bearer valid-admin-token" http://127.0.0.1:5000/api/enrollments
curl -H "Authorization: Bearer valid-admin-token" http://127.0.0.1:5000/api/timetable
```

## 4. Test Gateway chặn request không token

```bash
curl http://127.0.0.1:5000/api/students
```

Kết quả mong đợi: HTTP 401 Unauthorized.

## 5. Test RabbitMQ EDA

```powershell
docker run -d --hostname rabbitmq-host --name rabbitmq -p 5672:5672 -p 15672:15672 rabbitmq:3-management
python eda/rabbitmq_consumer.py
python eda/rabbitmq_producer.py
```
