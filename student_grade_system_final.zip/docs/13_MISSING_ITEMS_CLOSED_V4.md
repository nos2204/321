# Các phần đã bổ sung ở bản V4

Bản V4 bổ sung các phần còn thiếu để bám sát chuỗi Lab 1–8:

1. **Sơ đồ draw.io**: Use Case, Component Layered, C4 Context, Deployment.
2. **Microservices độc lập hơn**: mỗi service có database SQLite riêng, route `/health`, REST API CRUD chính.
3. **API Gateway hoàn chỉnh hơn**: kiểm tra token, phân quyền theo role, health check, xử lý service offline.
4. **EDA gắn nghiệp vụ thật hơn**: EnrollmentCreatedEvent, EnrollmentCancelledEvent, GradeUpdatedEvent được publish khi thao tác nghiệp vụ xảy ra.
5. **Docker full**: `docker-compose.full.yml` chạy Gateway, RabbitMQ, các microservice.
6. **Test tự động**: thư mục `tests/` kiểm tra contract cơ bản và sự tồn tại của artifacts kiến trúc.

## Phần vẫn giữ lại có chủ đích

`presentation/routes/legacy_monolith.py` vẫn được giữ để hệ thống web QLSV hiện tại không bị mất chức năng. Đây là lớp tương thích (compatibility layer). Nếu cần 100% sạch tuyệt đối, cần tách tiếp file này thành nhiều Blueprint nhỏ.
