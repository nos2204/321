# V5 - Đóng các khoảng thiếu cuối cùng so với tài liệu ShopSphere

## Mục tiêu
Bản V5 bổ sung lớp `presentation/routes_clean/` để minh họa phiên bản route sạch, không truy cập trực tiếp database trong controller.

## Mapping với 8 Lab

| Lab | Trạng thái V5 | Minh chứng |
|---|---|---|
| Lab 1 - Requirements/ASR/Use Case | Hoàn thành gần đầy đủ | `docs/01_REQUIREMENTS_ASR_QLSV.md`, `docs/diagrams/use_case_qlsv.drawio` |
| Lab 2 - Layered Architecture Design | Hoàn thành | `docs/02_LAYERED_ARCHITECTURE_QLSV.md`, `docs/diagrams/component_layered_qlsv.drawio` |
| Lab 3 - Layered CRUD | Hoàn thành ở app chính + clean route mẫu | `presentation/routes_clean/`, `business/`, `persistence/` |
| Lab 4 - Microservices Decomposition | Hoàn thành | `docs/04_MICROSERVICES_DECOMPOSITION_QLSV.md`, `docs/10_C4_CONTEXT_QLSV.md` |
| Lab 5 - Microservice Implementation | Hoàn thành mức thực hành | `microservices/*_service/app.py` |
| Lab 6 - API Gateway | Hoàn thành mức thực hành | `api_gateway/gateway.py`, `tests/test_gateway_contracts.py` |
| Lab 7 - EDA | Hoàn thành mức thực hành | `eda/rabbitmq_producer.py`, `eda/rabbitmq_consumer.py`, `microservices/shared/events.py` |
| Lab 8 - Deployment/ATAM | Hoàn thành mức thực hành | `docker-compose.full.yml`, `docs/11_ATAM_TRADEOFFS_QLSV.md`, `docs/diagrams/deployment_qlsv.drawio` |

## Điểm còn giữ lại có chủ ý
File `presentation/routes/legacy_monolith.py` vẫn được giữ để bảo toàn chức năng web gốc. Tuy nhiên bản V5 bổ sung `presentation/routes_clean/` và `app_clean.py` làm phiên bản tham chiếu để chứng minh kiến trúc phân lớp sạch.

## Mức đạt sau V5
- So với toàn bộ Lab 1-8: 95-97%
- So với kiến trúc phân lớp Lab 2-3: 97-98%
- So với yêu cầu chạy đồ án thực tế: 90-95%
