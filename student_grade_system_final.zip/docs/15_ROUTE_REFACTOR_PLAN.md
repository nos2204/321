# Kế hoạch tách hoàn toàn legacy_monolith.py

Để đạt 100% tuyệt đối theo kiến trúc phân lớp, thực hiện tuần tự:

1. Chuyển nhóm Auth từ `legacy_monolith.py` sang `presentation/routes_clean/auth_routes.py`.
2. Chuyển nhóm Student sang `student_routes.py`; mọi truy vấn đi qua `StudentService`.
3. Chuyển nhóm Grade sang `grade_routes.py`; mọi query đi qua `GradeService` và `GradeRepository`.
4. Chuyển nhóm Enrollment sang `enrollment_routes.py`; sau khi đăng ký thành công publish `EnrollmentCreatedEvent`.
5. Chuyển nhóm Timetable sang `timetable_routes.py`.
6. Khi tất cả route cũ đã chuyển xong, đổi `app.py` sang dùng `app_clean.py` và đưa `legacy_monolith.py` vào thư mục `archive/`.

Quy tắc bắt buộc:

```text
Route/Controller không dùng Model.query hoặc db.session trực tiếp.
Route/Controller chỉ gọi Service.
Service chỉ gọi Repository.
Repository mới được truy cập ORM/database.
```
