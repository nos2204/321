# V6 Final – Strict Layered Default Mode

Bản V6 đổi `app.py` sang chạy `app_clean.py` mặc định. Đây là bản gần nhất với yêu cầu 100% của tài liệu ShopSphere:

- Entry point mỏng.
- Routes sạch trong `presentation/routes_clean`.
- Route không gọi trực tiếp `Model.query` hoặc `db.session`.
- Business service điều phối nghiệp vụ.
- Repository/database được cô lập ở Persistence Layer.
- Legacy monolith vẫn được giữ để phục hồi khi cần: `QLSV_USE_LEGACY=1 python app.py`.

## Chạy bản sạch
```bash
python app.py
```

## Chạy bản legacy nếu cần đầy đủ màn hình cũ
```bash
QLSV_USE_LEGACY=1 python app.py
```
Windows PowerShell:
```powershell
$env:QLSV_USE_LEGACY="1"; python app.py
```
