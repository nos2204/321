# V7 Strict Final - 100% Layered Default Mode

## Mục tiêu

V7 đóng khoảng cách còn lại của V6 bằng cách bỏ legacy router khỏi đường chạy mặc định và khỏi source tree route chính.

## Luồng mặc định

```text
app.py
  -> app_clean.py
      -> presentation/routes_clean
          -> business services
              -> persistence repositories
                  -> Data Layer
```

## Quy tắc bắt buộc

Presentation routes không được gọi trực tiếp:

```text
Model.query
.db.session
SQL trực tiếp
```

Database access chỉ nằm ở Persistence Layer.

## Mapping với tài liệu ShopSphere

- Lab 1: Có tài liệu Requirements, ASR, Use Case, `.drawio`.
- Lab 2: Có kiến trúc phân lớp rõ ràng và Component Diagram.
- Lab 3: App mặc định chạy strict layered route.
- Lab 4: Có tài liệu phân rã microservices theo năng lực nghiệp vụ.
- Lab 5: Có microservices độc lập.
- Lab 6: Có API Gateway routing, token, role, health check.
- Lab 7: Có RabbitMQ Producer/Consumer và domain events.
- Lab 8: Có Docker Compose, Deployment Diagram, ATAM, trade-offs.

## Ghi chú

Các trang giao diện chưa migrate đầy đủ vẫn có compatibility endpoints trong `routes_clean/compat_routes.py`, nhưng các endpoint này vẫn tuân thủ nguyên tắc route chỉ gọi Business Service, không query database trực tiếp.
