"""Event bus tối giản để minh họa EDA khi chưa chạy RabbitMQ."""
from collections import defaultdict

_subscribers = defaultdict(list)


def subscribe(event_name, handler):
    _subscribers[event_name].append(handler)


def publish(event_name, payload):
    for handler in _subscribers[event_name]:
        handler(payload)
