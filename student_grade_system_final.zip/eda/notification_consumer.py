"""Consumer minh họa: nhận sự kiện và in thông báo."""
from event_bus import subscribe


def handle_grade_updated(payload):
    print(f"[Notification] Điểm đã cập nhật: {payload}")


def handle_enrollment_registered(payload):
    print(f"[Notification] Đăng ký học phần mới: {payload}")


subscribe('GradeUpdatedEvent', handle_grade_updated)
subscribe('EnrollmentRegisteredEvent', handle_enrollment_registered)
