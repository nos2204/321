"""Producer demo cho EDA local."""
import notification_consumer  # noqa: F401 - đăng ký consumer
from event_bus import publish

publish('GradeUpdatedEvent', {'student_id': 1, 'subject': 'KTCB', 'final_grade': 8.2})
publish('EnrollmentRegisteredEvent', {'student_id': 1, 'section_id': 10})
