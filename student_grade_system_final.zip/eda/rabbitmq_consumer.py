"""Consumer cho kiến trúc EDA QLSV.
Lắng nghe queue qlsv_events và mô phỏng gửi thông báo.
"""
import json
import os
import pika

RABBITMQ_URL = os.environ.get('RABBITMQ_URL', 'amqp://guest:guest@localhost:5672/%2F')
QUEUE_NAME = os.environ.get('QUEUE_NAME', 'qlsv_events')


def handle_message(ch, method, properties, body):
    event = json.loads(body.decode('utf-8'))
    print('[EVENT CONSUMED]', event)
    if event.get('event_type') == 'EnrollmentCreated':
        payload = event.get('payload', {})
        print(f"Gửi email mô phỏng: {payload.get('email')} đã đăng ký {payload.get('section_code')}")
    ch.basic_ack(delivery_tag=method.delivery_tag)


if __name__ == '__main__':
    params = pika.URLParameters(RABBITMQ_URL)
    connection = pika.BlockingConnection(params)
    channel = connection.channel()
    channel.queue_declare(queue=QUEUE_NAME, durable=True)
    channel.basic_qos(prefetch_count=1)
    channel.basic_consume(queue=QUEUE_NAME, on_message_callback=handle_message)
    print(f'Notification Consumer listening queue={QUEUE_NAME}')
    channel.start_consuming()
