"""Producer cho kiến trúc hướng sự kiện QLSV.
Phát sự kiện khi có đăng ký học phần / nhập điểm / tạo tài khoản.
Cần RabbitMQ đang chạy: docker compose up rabbitmq
"""
import json
import os
import pika

RABBITMQ_URL = os.environ.get('RABBITMQ_URL', 'amqp://guest:guest@localhost:5672/%2F')
QUEUE_NAME = os.environ.get('QUEUE_NAME', 'qlsv_events')


def publish_event(event_type, payload):
    params = pika.URLParameters(RABBITMQ_URL)
    connection = pika.BlockingConnection(params)
    channel = connection.channel()
    channel.queue_declare(queue=QUEUE_NAME, durable=True)
    message = json.dumps({'event_type': event_type, 'payload': payload}, ensure_ascii=False)
    channel.basic_publish(
        exchange='',
        routing_key=QUEUE_NAME,
        body=message.encode('utf-8'),
        properties=pika.BasicProperties(delivery_mode=2),
    )
    connection.close()
    print('[EVENT PUBLISHED]', message)


if __name__ == '__main__':
    publish_event('EnrollmentCreated', {'student_code': 'SV001', 'section_code': 'KT-CB-01', 'email': 'student@example.com'})
