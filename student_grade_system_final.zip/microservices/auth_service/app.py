from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('AUTH_DATABASE_URI', 'sqlite:///auth_service.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

TOKENS = {
    'admin': 'valid-admin-token',
    'teacher': 'valid-teacher-token',
    'student': 'valid-student-token',
}

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='student')

    def to_dict(self):
        return {'id': self.id, 'username': self.username, 'role': self.role}

@app.before_request
def init_db():
    if getattr(app, '_db_ready', False):
        return
    app._db_ready = True
    db.create_all()
    if not User.query.filter_by(username='admin').first():
        db.session.add(User(username='admin', password_hash=generate_password_hash('admin123'), role='admin'))
        db.session.add(User(username='teacher', password_hash=generate_password_hash('teacher123'), role='teacher'))
        db.session.add(User(username='student', password_hash=generate_password_hash('student123'), role='student'))
        db.session.commit()

@app.get('/health')
def health():
    return jsonify({'service': 'auth_service', 'status': 'ok'}), 200

@app.post('/api/auth/login')
def login():
    data = request.get_json(silent=True) or {}
    username = (data.get('username') or '').strip()
    password = data.get('password') or ''
    user = User.query.filter_by(username=username).first()
    if not user or not check_password_hash(user.password_hash, password):
        return jsonify({'error': 'Tài khoản hoặc mật khẩu không chính xác'}), 401
    return jsonify({'user': user.to_dict(), 'token': TOKENS.get(user.role, 'valid-student-token')}), 200

@app.get('/api/users')
def list_users():
    return jsonify([u.to_dict() for u in User.query.all()]), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5002)), debug=True)
