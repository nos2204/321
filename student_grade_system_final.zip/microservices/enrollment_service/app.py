from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
import os, sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from shared.security import token_required, role_required
from shared.events import publish_event

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('ENROLLMENT_DATABASE_URI', 'sqlite:///enrollment_service.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Enrollment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_code = db.Column(db.String(30), nullable=False)
    section_code = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(20), default='registered')
    def to_dict(self): return {'id': self.id, 'student_code': self.student_code, 'section_code': self.section_code, 'status': self.status}

@app.before_request
def init_db():
    if getattr(app, '_db_ready', False): return
    app._db_ready = True; db.create_all()

@app.get('/health')
def health(): return jsonify({'service': 'enrollment_service', 'status': 'ok'}), 200

@app.get('/api/enrollments')
@token_required
def list_enrollments():
    student_code = request.args.get('student_code')
    q = Enrollment.query
    if student_code: q = q.filter_by(student_code=student_code)
    return jsonify([e.to_dict() for e in q.all()]), 200

@app.post('/api/enrollments')
@role_required('admin', 'student')
def register():
    data = request.get_json(silent=True) or {}
    if not data.get('student_code') or not data.get('section_code'):
        return jsonify({'error': 'Thiếu student_code hoặc section_code'}), 400
    existing = Enrollment.query.filter_by(student_code=data['student_code'], section_code=data['section_code']).first()
    if existing: return jsonify({'error': 'Sinh viên đã đăng ký lớp học phần này'}), 409
    e = Enrollment(student_code=data['student_code'], section_code=data['section_code'])
    db.session.add(e); db.session.commit()
    publish_event('EnrollmentCreatedEvent', e.to_dict())
    return jsonify(e.to_dict()), 201

@app.delete('/api/enrollments/<int:enrollment_id>')
@role_required('admin', 'student')
def cancel(enrollment_id):
    e = Enrollment.query.get(enrollment_id)
    if not e: return jsonify({'error': 'Enrollment not found'}), 404
    payload = e.to_dict(); db.session.delete(e); db.session.commit()
    publish_event('EnrollmentCancelledEvent', payload)
    return jsonify({'message': 'Đã hủy đăng ký'}), 200

if __name__ == '__main__': app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5005)), debug=True)
