from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
import os, sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from shared.security import token_required, role_required
from shared.events import publish_event

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('GRADE_DATABASE_URI', 'sqlite:///grade_service.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Grade(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_code = db.Column(db.String(30), nullable=False)
    subject_code = db.Column(db.String(30), nullable=False)
    progress_grade = db.Column(db.Float, default=0)
    exam_grade = db.Column(db.Float, default=0)
    def final_grade(self): return round((self.progress_grade or 0)*0.4 + (self.exam_grade or 0)*0.6, 2)
    def to_dict(self): return {'id':self.id,'student_code':self.student_code,'subject_code':self.subject_code,'progress_grade':self.progress_grade,'exam_grade':self.exam_grade,'final_grade':self.final_grade()}

@app.before_request
def init_db_once():
    if getattr(app, '_db_ready', False): return
    app._db_ready = True; db.create_all()

@app.get('/health')
def health(): return jsonify({'service':'grade_service','status':'ok'}), 200

@app.get('/api/grades')
@token_required
def list_grades():
    student_code = request.args.get('student_code')
    q = Grade.query
    if student_code: q = q.filter_by(student_code=student_code)
    return jsonify([g.to_dict() for g in q.all()]), 200

@app.post('/api/grades')
@role_required('admin','teacher')
def upsert_grade():
    data = request.get_json(silent=True) or {}
    required = ['student_code','subject_code','progress_grade','exam_grade']
    if any(k not in data for k in required): return jsonify({'error':'Thiếu dữ liệu điểm'}), 400
    g = Grade.query.filter_by(student_code=data['student_code'], subject_code=data['subject_code']).first()
    if not g:
        g = Grade(student_code=data['student_code'], subject_code=data['subject_code']); db.session.add(g)
    g.progress_grade = float(data['progress_grade']); g.exam_grade = float(data['exam_grade'])
    db.session.commit()
    publish_event('GradeUpdatedEvent', g.to_dict())
    return jsonify(g.to_dict()), 200

@app.delete('/api/grades/<int:grade_id>')
@role_required('admin')
def delete_grade(grade_id):
    g = Grade.query.get(grade_id)
    if not g: return jsonify({'error':'Grade not found'}), 404
    db.session.delete(g); db.session.commit(); return jsonify({'message':'Đã xóa điểm'}), 200

if __name__ == '__main__': app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5003)), debug=True)
