"""Notification Service cho kiến trúc EDA.
Chạy độc lập để nhận thông báo HTTP hoặc dùng consumer RabbitMQ trong eda/rabbitmq_consumer.py.
"""
from flask import Flask, request, jsonify
import os
app = Flask(__name__)

@app.get('/health')
def health(): return jsonify({'service': 'notification_service', 'status': 'ok'}), 200

@app.post('/api/notifications')
def notify():
    data = request.get_json(silent=True) or {}
    print('[NOTIFICATION]', data)
    return jsonify({'message': 'Đã nhận thông báo', 'payload': data}), 202

if __name__ == '__main__': app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5007)), debug=True)
