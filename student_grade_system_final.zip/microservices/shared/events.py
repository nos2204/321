import json
import os
import time

try:
    import pika
except Exception:  # pika may be unavailable in local monolith runs
    pika = None

RABBITMQ_URL = os.environ.get('RABBITMQ_URL', 'amqp://guest:guest@rabbitmq:5672/%2F')
QUEUE_NAME = os.environ.get('EVENT_QUEUE', 'qlsv_events')
OUTBOX_FILE = os.environ.get('EVENT_OUTBOX_FILE', 'event_outbox.jsonl')


def publish_event(event_type, payload):
    """Publish event to RabbitMQ; fallback to local outbox file if broker is unavailable."""
    event = {
        'event_type': event_type,
        'payload': payload,
        'created_at': int(time.time())
    }
    if pika:
        try:
            params = pika.URLParameters(RABBITMQ_URL)
            connection = pika.BlockingConnection(params)
            channel = connection.channel()
            channel.queue_declare(queue=QUEUE_NAME, durable=True)
            channel.basic_publish(
                exchange='',
                routing_key=QUEUE_NAME,
                body=json.dumps(event, ensure_ascii=False).encode('utf-8'),
                properties=pika.BasicProperties(delivery_mode=2),
            )
            connection.close()
            return {'published': True, 'event': event}
        except Exception as exc:
            event['broker_error'] = str(exc)
    with open(OUTBOX_FILE, 'a', encoding='utf-8') as f:
        f.write(json.dumps(event, ensure_ascii=False) + '\n')
    return {'published': False, 'stored_in_outbox': OUTBOX_FILE, 'event': event}
