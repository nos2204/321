from functools import wraps
from flask import request, jsonify

VALID_TOKENS = {
    'valid-admin-token': 'admin',
    'valid-teacher-token': 'teacher',
    'valid-student-token': 'student',
}

def get_role_from_request():
    auth = request.headers.get('Authorization', '')
    if not auth.startswith('Bearer '):
        return None
    token = auth.replace('Bearer ', '', 1).strip()
    return VALID_TOKENS.get(token)

def token_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        role = get_role_from_request()
        if not role:
            return jsonify({'error': 'Unauthorized', 'details': 'Thiếu hoặc sai Bearer token'}), 401
        request.user_role = role
        return fn(*args, **kwargs)
    return wrapper

def role_required(*roles):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            role = get_role_from_request()
            if not role:
                return jsonify({'error': 'Unauthorized', 'details': 'Thiếu hoặc sai Bearer token'}), 401
            if role not in roles:
                return jsonify({'error': 'Forbidden', 'details': f'Cần quyền: {roles}'}), 403
            request.user_role = role
            return fn(*args, **kwargs)
        return wrapper
    return decorator
