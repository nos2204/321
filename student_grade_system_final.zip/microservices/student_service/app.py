from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
import os, sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from shared.security import token_required, role_required

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('STUDENT_DATABASE_URI', 'sqlite:///student_service.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_code = db.Column(db.String(30), unique=True, nullable=False)
    full_name = db.Column(db.String(120), nullable=False)
    class_name = db.Column(db.String(80))
    email = db.Column(db.String(120))
    phone = db.Column(db.String(30))
    status = db.Column(db.String(20), default='active')
    def to_dict(self):
        return {'id': self.id, 'student_code': self.student_code, 'full_name': self.full_name, 'class_name': self.class_name, 'email': self.email, 'phone': self.phone, 'status': self.status}

@app.before_request
def init_db_once():
    if getattr(app, '_db_ready', False): return
    app._db_ready = True; db.create_all()
    if Student.query.count() == 0:
        db.session.add(Student(student_code='SV001', full_name='Nguyễn Văn A', class_name='CNTT01', email='sv001@example.com'))
        db.session.commit()

@app.get('/health')
def health(): return jsonify({'service': 'student_service', 'status': 'ok'}), 200

@app.get('/api/students')
@token_required
def list_students():
    q = request.args.get('q', '').strip()
    query = Student.query
    if q: query = query.filter((Student.full_name.like(f'%{q}%')) | (Student.student_code.like(f'%{q}%')))
    return jsonify([s.to_dict() for s in query.order_by(Student.id.desc()).all()]), 200

@app.get('/api/students/<int:student_id>')
@token_required
def get_student(student_id):
    s = Student.query.get(student_id)
    if not s: return jsonify({'error': 'Student not found'}), 404
    return jsonify(s.to_dict()), 200

@app.post('/api/students')
@role_required('admin')
def create_student():
    data = request.get_json(silent=True) or {}
    if not data.get('student_code') or not data.get('full_name'):
        return jsonify({'error': 'student_code và full_name là bắt buộc'}), 400
    if Student.query.filter_by(student_code=data['student_code']).first():
        return jsonify({'error': 'Mã sinh viên đã tồn tại'}), 409
    s = Student(student_code=data['student_code'], full_name=data['full_name'], class_name=data.get('class_name'), email=data.get('email'), phone=data.get('phone'), status=data.get('status','active'))
    db.session.add(s); db.session.commit()
    return jsonify(s.to_dict()), 201

@app.put('/api/students/<int:student_id>')
@role_required('admin')
def update_student(student_id):
    s = Student.query.get(student_id)
    if not s: return jsonify({'error': 'Student not found'}), 404
    data = request.get_json(silent=True) or {}
    for k in ['full_name','class_name','email','phone','status']:
        if k in data: setattr(s, k, data[k])
    db.session.commit(); return jsonify(s.to_dict()), 200

@app.delete('/api/students/<int:student_id>')
@role_required('admin')
def delete_student(student_id):
    s = Student.query.get(student_id)
    if not s: return jsonify({'error': 'Student not found'}), 404
    db.session.delete(s); db.session.commit(); return jsonify({'message':'Đã xóa sinh viên'}), 200

if __name__ == '__main__': app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5001)), debug=True)
