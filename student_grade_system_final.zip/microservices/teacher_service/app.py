from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
import os, sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from shared.security import token_required, role_required

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('TEACHER_DATABASE_URI', 'sqlite:///teacher_service.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Teacher(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(30), unique=True, nullable=False)
    full_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120))
    department = db.Column(db.String(120))

    def to_dict(self):
        return {'id': self.id, 'code': self.code, 'full_name': self.full_name, 'email': self.email, 'department': self.department}

@app.before_request
def init_db():
    if getattr(app, '_db_ready', False): return
    app._db_ready = True
    db.create_all()
    if not Teacher.query.first():
        db.session.add(Teacher(code='GV001', full_name='Lê Minh Huy', email='huy@example.com', department='CNTT'))
        db.session.commit()

@app.get('/health')
def health(): return jsonify({'service': 'teacher_service', 'status': 'ok'}), 200

@app.get('/api/teachers')
@token_required
def list_teachers(): return jsonify([t.to_dict() for t in Teacher.query.all()]), 200

@app.get('/api/teachers/<int:teacher_id>')
@token_required
def get_teacher(teacher_id):
    t = Teacher.query.get_or_404(teacher_id)
    return jsonify(t.to_dict()), 200

@app.post('/api/teachers')
@role_required('admin')
def create_teacher():
    data = request.get_json(silent=True) or {}
    if not data.get('code') or not data.get('full_name'):
        return jsonify({'error': 'Thiếu mã hoặc tên giảng viên'}), 400
    t = Teacher(code=data['code'], full_name=data['full_name'], email=data.get('email'), department=data.get('department'))
    db.session.add(t); db.session.commit()
    return jsonify(t.to_dict()), 201

if __name__ == '__main__': app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5004)), debug=True)
