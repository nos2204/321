from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
import os, sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from shared.security import token_required, role_required

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('TIMETABLE_DATABASE_URI', 'sqlite:///timetable_service.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class TimetableEvent(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    subject_name = db.Column(db.String(120), nullable=False)
    section_code = db.Column(db.String(50), nullable=False)
    teacher_code = db.Column(db.String(30))
    day_of_week = db.Column(db.Integer, nullable=False)
    start_time = db.Column(db.String(5), nullable=False)
    end_time = db.Column(db.String(5), nullable=False)
    room = db.Column(db.String(50))

    def to_dict(self):
        return {'id': self.id, 'subject_name': self.subject_name, 'section_code': self.section_code, 'teacher_code': self.teacher_code, 'day_of_week': self.day_of_week, 'start_time': self.start_time, 'end_time': self.end_time, 'room': self.room}

@app.before_request
def init_db():
    if getattr(app, '_db_ready', False): return
    app._db_ready = True; db.create_all()
    if not TimetableEvent.query.first():
        db.session.add(TimetableEvent(subject_name='Kỹ thuật cảm biến', section_code='KT-CB-01', teacher_code='GV001', day_of_week=2, start_time='06:45', end_time='09:25', room='A1-602.603'))
        db.session.commit()

@app.get('/health')
def health(): return jsonify({'service': 'timetable_service', 'status': 'ok'}), 200

@app.get('/api/timetable')
@token_required
def list_events():
    teacher_code = request.args.get('teacher_code')
    q = TimetableEvent.query
    if teacher_code: q = q.filter_by(teacher_code=teacher_code)
    return jsonify([e.to_dict() for e in q.all()]), 200

@app.post('/api/timetable')
@role_required('admin')
def create_event():
    data = request.get_json(silent=True) or {}
    required = ['subject_name', 'section_code', 'day_of_week', 'start_time', 'end_time']
    if any(not data.get(k) for k in required): return jsonify({'error': 'Thiếu dữ liệu lịch học'}), 400
    e = TimetableEvent(**{k: data.get(k) for k in ['subject_name','section_code','teacher_code','day_of_week','start_time','end_time','room']})
    db.session.add(e); db.session.commit()
    return jsonify(e.to_dict()), 201

if __name__ == '__main__': app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5006)), debug=True)
