"""Data Layer entry point."""
from persistence.models import db

__all__ = ['db']
