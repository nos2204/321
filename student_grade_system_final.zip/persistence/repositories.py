"""Persistence Layer repositories for the Student Grade System.

Theo kiến trúc phân lớp trong tài liệu ShopSphere, lớp Repository là nơi duy nhất
đóng gói thao tác truy cập dữ liệu. Presentation/Controller không nên query database
trực tiếp khi có thể gọi qua Business Service.
"""
from __future__ import annotations

from typing import Optional
from persistence.models import (
    db,
    UserModel,
    StudentModel,
    SubjectModel,
    GradeModel,
    SemesterModel,
    AuditLog,
    DepartmentModel,
    ClassModel,
    TeacherModel,
    CourseSectionModel,
    EnrollmentModel,
)


class BaseRepository:
    model = None

    def all(self):
        return self.model.query.all()

    def get(self, object_id):
        return self.model.query.get(object_id)

    def get_or_404(self, object_id):
        return self.model.query.get_or_404(object_id)

    def add(self, obj, commit=True):
        db.session.add(obj)
        if commit:
            db.session.commit()
        return obj

    def delete(self, obj, commit=True):
        db.session.delete(obj)
        if commit:
            db.session.commit()
        return True

    def commit(self):
        db.session.commit()

    def rollback(self):
        db.session.rollback()


class UserRepository(BaseRepository):
    model = UserModel

    def find_by_username(self, username: str) -> Optional[UserModel]:
        return UserModel.query.filter_by(username=username).first()

    def count(self) -> int:
        return UserModel.query.count()


class StudentRepository(BaseRepository):
    model = StudentModel

    def find_by_code(self, student_code: str) -> Optional[StudentModel]:
        return StudentModel.query.filter_by(student_code=student_code).first()

    def count(self) -> int:
        return StudentModel.query.count()

    def count_by_rank(self, academic_rank: str) -> int:
        return StudentModel.query.filter_by(academic_rank=academic_rank).count()

    def count_by_gender(self, gender: str) -> int:
        return StudentModel.query.filter_by(gender=gender).count()

    def top_by_gpa(self, limit=5):
        return StudentModel.query.filter(StudentModel.gpa > 0).order_by(StudentModel.gpa.desc()).limit(limit).all()

    def count_without_account(self) -> int:
        return StudentModel.query.filter(
            ~StudentModel.id.in_(db.session.query(UserModel.student_id).filter(UserModel.student_id.isnot(None)))
        ).count()

    def count_without_grade(self) -> int:
        return StudentModel.query.filter(
            ~StudentModel.id.in_(db.session.query(GradeModel.student_id))
        ).count()


class SubjectRepository(BaseRepository):
    model = SubjectModel

    def find_by_code(self, subject_code: str) -> Optional[SubjectModel]:
        return SubjectModel.query.filter_by(subject_code=subject_code).first()

    def count(self) -> int:
        return SubjectModel.query.count()


class GradeRepository(BaseRepository):
    model = GradeModel

    def find_student_subject_semester(self, student_id, subject_id, semester_id):
        return GradeModel.query.filter_by(
            student_id=student_id,
            subject_id=subject_id,
            semester_id=semester_id,
        ).first()


class SemesterRepository(BaseRepository):
    model = SemesterModel

    def current(self):
        return SemesterModel.query.filter_by(is_current=True).first()

    def count(self) -> int:
        return SemesterModel.query.count()


class DepartmentRepository(BaseRepository):
    model = DepartmentModel

    def count(self) -> int:
        return DepartmentModel.query.count()


class ClassRepository(BaseRepository):
    model = ClassModel

    def count(self) -> int:
        return ClassModel.query.count()


class TeacherRepository(BaseRepository):
    model = TeacherModel

    def count(self) -> int:
        return TeacherModel.query.count()


class CourseSectionRepository(BaseRepository):
    model = CourseSectionModel

    def count(self) -> int:
        return CourseSectionModel.query.count()


class EnrollmentRepository(BaseRepository):
    model = EnrollmentModel

    def registered_count(self) -> int:
        return EnrollmentModel.query.filter_by(status='registered').count()

    def find_registered(self, student_id, section_id):
        return EnrollmentModel.query.filter_by(
            student_id=student_id,
            section_id=section_id,
            status='registered',
        ).first()

    def by_student(self, student_id):
        return EnrollmentModel.query.filter_by(student_id=student_id).all()


class AuditLogRepository(BaseRepository):
    model = AuditLog

    def write(self, actor, action, target=None, detail=None, commit=True):
        log = AuditLog(actor=actor, action=action, target=target, detail=detail)
        db.session.add(log)
        if commit:
            db.session.commit()
        return log

# ===== Repository bổ sung cho phiên bản kiến trúc phân lớp đầy đủ hơn =====
class TeacherRepository(BaseRepository):
    model = TeacherModel

    def count(self) -> int:
        return TeacherModel.query.count()

    def find_by_code(self, teacher_code: str):
        return TeacherModel.query.filter_by(teacher_code=teacher_code).first()

    def ordered(self):
        return TeacherModel.query.order_by(TeacherModel.full_name).all()


class DepartmentRepository(BaseRepository):
    model = DepartmentModel

    def count(self) -> int:
        return DepartmentModel.query.count()

    def find_by_code(self, department_code: str):
        return DepartmentModel.query.filter_by(department_code=department_code).first()

    def ordered(self):
        return DepartmentModel.query.order_by(DepartmentModel.department_name).all()


class ClassRepository(BaseRepository):
    model = ClassModel

    def count(self) -> int:
        return ClassModel.query.count()

    def find_by_code(self, class_code: str):
        return ClassModel.query.filter_by(class_code=class_code).first()

    def ordered(self):
        return ClassModel.query.order_by(ClassModel.class_code).all()


class SubjectRepository(BaseRepository):
    model = SubjectModel

    def find_by_code(self, subject_code: str):
        return SubjectModel.query.filter_by(subject_code=subject_code).first()

    def count(self) -> int:
        return SubjectModel.query.count()

    def ordered(self):
        return SubjectModel.query.order_by(SubjectModel.subject_name).all()


class SemesterRepository(BaseRepository):
    model = SemesterModel

    def current(self):
        return SemesterModel.query.filter_by(is_current=True).first()

    def count(self) -> int:
        return SemesterModel.query.count()

    def ordered(self):
        return SemesterModel.query.order_by(SemesterModel.academic_year.desc(), SemesterModel.name).all()


class CourseSectionRepository(BaseRepository):
    model = CourseSectionModel

    def count(self) -> int:
        return CourseSectionModel.query.count()

    def open_sections(self):
        return CourseSectionModel.query.filter_by(status='open').all()

    def by_teacher(self, teacher_id):
        return CourseSectionModel.query.filter_by(teacher_id=teacher_id).all()

    def ordered(self):
        return CourseSectionModel.query.order_by(CourseSectionModel.section_code).all()
