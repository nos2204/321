# Routes layer in V7 Strict Final

V7 removes the old `legacy_monolith.py` from the runnable source tree.
All default web routes are registered from `presentation/routes_clean/`.

Layer rule:

```text
Route / Controller -> Business Service -> Repository -> Database
```

Routes in this folder must not call `Model.query`, `db.session`, or any direct database operation.
