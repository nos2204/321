# Presentation Routes

Theo tài liệu ShopSphere, Presentation Layer nhận HTTP request, quản lý session và render UI.

Trong phiên bản làm lại:

- `legacy_monolith.py`: giữ toàn bộ route hiện có để đảm bảo hệ thống chạy đầy đủ.
- Các service nghiệp vụ đã được đặt trong `business/` để route có thể gọi dần theo đúng luồng.

Luồng mục tiêu:

```text
Route/Controller → Business Service → Repository → Database
```

Khi phát triển tiếp, có thể tách dần file này thành:

```text
auth_routes.py
student_routes.py
teacher_routes.py
grade_routes.py
enrollment_routes.py
timetable_routes.py
admin_routes.py
```
