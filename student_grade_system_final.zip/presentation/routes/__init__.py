"""Presentation Layer package.

Routes/controllers are currently registered in app.py to preserve endpoint names used by
existing templates. New features should be added as Flask Blueprints in this package.
"""
