"""Clean Blueprint routes for QLSV strict layered architecture.

These routes are designed to follow:
Presentation -> Business Service -> Repository -> Database.
They intentionally avoid direct database operations.
"""

from .auth_routes import auth_bp
from .dashboard_routes import dashboard_bp
from .student_routes import student_bp
from .grade_routes import grade_bp
from .enrollment_routes import enrollment_bp
from .timetable_routes import timetable_bp
from .compat_routes import compat_bp

CLEAN_BLUEPRINTS = [auth_bp, dashboard_bp, student_bp, grade_bp, enrollment_bp, timetable_bp, compat_bp]
