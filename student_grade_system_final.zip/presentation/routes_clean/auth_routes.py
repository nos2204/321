from __future__ import annotations

from flask import Blueprint, flash, redirect, render_template, request, session, url_for

from business.auth_service import AuthService

auth_bp = Blueprint('auth_clean', __name__)
auth_service = AuthService()


@auth_bp.route('/clean/login', methods=['GET', 'POST'])
def login():
    old_username = ''
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        old_username = username

        result = auth_service.authenticate(username, password)
        if result.success:
            user = result.user
            session['username'] = user.username
            session['role'] = user.role
            session['linked_student_id'] = user.student_id
            session['linked_teacher_id'] = user.teacher_id
            flash(result.message, 'success')
            return redirect(url_for('dashboard'))

        flash(result.message, 'danger')
        return render_template('login.html', old_username=old_username)

    return render_template('login.html', old_username=old_username)


@auth_bp.route('/clean/logout')
def logout():
    session.clear()
    flash('Đã đăng xuất.', 'success')
    return redirect(url_for('auth_clean.login'))
