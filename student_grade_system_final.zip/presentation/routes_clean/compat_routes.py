from __future__ import annotations

from flask import Blueprint, redirect, render_template, url_for

from business.dashboard_service import DashboardService

compat_bp = Blueprint('compat_clean', __name__)
dashboard_service = DashboardService()


def render_not_ready_page():
    """Compatibility page for screens not yet migrated to a full clean route.

    It intentionally calls Business Service only and does not access the database directly.
    """
    context = dashboard_service.get_stats()
    return render_template('dashboard.html', **context)


@compat_bp.route('/')
def dashboard():
    return redirect(url_for('dashboard_clean.dashboard'))


@compat_bp.route('/login', methods=['GET', 'POST'])
def login():
    return redirect(url_for('auth_clean.login'))


@compat_bp.route('/logout')
def logout():
    return redirect(url_for('auth_clean.logout'))


@compat_bp.route('/students')
def students_manager():
    return redirect(url_for('students_clean.list_students'))


@compat_bp.route('/students/add')
def add_student():
    return redirect(url_for('students_clean.list_students'))


@compat_bp.route('/students/<int:student_id>')
def student_detail(student_id):
    return redirect(url_for('students_clean.detail_student', student_id=student_id))


@compat_bp.route('/students/<int:student_id>/edit')
def edit_student(student_id):
    return redirect(url_for('students_clean.detail_student', student_id=student_id))


@compat_bp.route('/students/<int:student_id>/grades')
def manage_grades(student_id):
    return redirect(url_for('grades_clean.student_grades', student_id=student_id))


@compat_bp.route('/timetable/admin')
def admin_timetable():
    return redirect(url_for('timetable_clean.admin_timetable'))


@compat_bp.route('/timetable/teacher')
def teacher_timetable():
    return redirect(url_for('timetable_clean.teacher_timetable'))


@compat_bp.route('/timetable/student')
def student_timetable():
    return redirect(url_for('timetable_clean.student_timetable'))


@compat_bp.route('/enrollments')
def enrollments_page():
    return redirect(url_for('enrollments_clean.register', section_id=1))


# Compatibility endpoints referenced by existing base.html.
# They are intentionally thin and call only the Business layer.
@compat_bp.route('/change-password')
def change_password():
    return render_not_ready_page()


@compat_bp.route('/profile')
def my_profile():
    return render_not_ready_page()


@compat_bp.route('/subjects')
def subjects_manager():
    return render_not_ready_page()


@compat_bp.route('/semesters')
def semesters_manager():
    return render_not_ready_page()


@compat_bp.route('/departments')
def departments_manager():
    return render_not_ready_page()


@compat_bp.route('/classes')
def classes_manager():
    return render_not_ready_page()


@compat_bp.route('/teachers')
def teachers_manager():
    return render_not_ready_page()


@compat_bp.route('/course-sections')
def course_sections_manager():
    return render_not_ready_page()


@compat_bp.route('/students/import')
def import_students():
    return render_not_ready_page()


@compat_bp.route('/grades/import')
def import_grades():
    return render_not_ready_page()


@compat_bp.route('/users')
def users_manager():
    return render_not_ready_page()


@compat_bp.route('/audit')
def audit_log():
    return render_not_ready_page()


@compat_bp.route('/teacher/sections')
def teacher_sections():
    return render_not_ready_page()


@compat_bp.route('/export/excel')
def export_excel():
    return render_not_ready_page()
