from __future__ import annotations

from flask import Blueprint, render_template

from business.dashboard_service import DashboardService

dashboard_bp = Blueprint('dashboard_clean', __name__)
dashboard_service = DashboardService()

@dashboard_bp.get('/')
def dashboard():
    stats = dashboard_service.get_stats()
    return render_template('dashboard.html', **stats)
