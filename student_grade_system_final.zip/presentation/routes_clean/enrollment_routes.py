from __future__ import annotations

from flask import Blueprint, jsonify

from business.enrollment_service import EnrollmentService

enrollment_bp = Blueprint('enrollments_clean', __name__, url_prefix='/clean/enrollments')
enrollment_service = EnrollmentService()


@enrollment_bp.post('/register/<int:section_id>')
def register(section_id: int):
    result = enrollment_service.register_current_student(section_id)
    return jsonify(result), 200


@enrollment_bp.post('/cancel/<int:enrollment_id>')
def cancel(enrollment_id: int):
    result = enrollment_service.cancel_current_student(enrollment_id)
    return jsonify(result), 200
