from __future__ import annotations

from flask import Blueprint, jsonify, request

from business.grade_service import GradeService

grade_bp = Blueprint('grades_clean', __name__, url_prefix='/clean/grades')
grade_service = GradeService()


@grade_bp.get('/student/<int:student_id>')
def student_grades(student_id: int):
    grades = grade_service.get_student_grades(student_id)
    return jsonify(grades), 200


@grade_bp.post('/student/<int:student_id>')
def save_student_grade(student_id: int):
    payload = request.get_json(silent=True) or request.form.to_dict()
    result = grade_service.save_grade(student_id, payload)
    return jsonify(result), 200
