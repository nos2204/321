from __future__ import annotations

from flask import Blueprint, jsonify, render_template, request

from business.student_service import StudentService

student_bp = Blueprint('students_clean', __name__, url_prefix='/clean/students')
student_service = StudentService()


@student_bp.get('')
def list_students():
    keyword = request.args.get('q', '').strip()
    students = student_service.list_students(keyword=keyword)
    if request.accept_mimetypes.accept_json and not request.accept_mimetypes.accept_html:
        return jsonify([s.to_dict() if hasattr(s, 'to_dict') else {'id': s.id, 'student_code': s.student_code, 'full_name': s.full_name} for s in students])
    return render_template('students.html', students=students, search=keyword)


@student_bp.get('/<int:student_id>')
def detail_student(student_id: int):
    student = student_service.get_student_or_404(student_id)
    return render_template('student_detail.html', student=student)


@student_bp.post('')
def create_student():
    payload = request.form.to_dict() or request.get_json(silent=True) or {}
    student = student_service.create_student(payload)
    return jsonify({'id': student.id, 'message': 'created'}), 201


@student_bp.put('/<int:student_id>')
def update_student(student_id: int):
    payload = request.get_json(silent=True) or {}
    student_service.update_student(student_id, payload)
    return jsonify({'message': 'updated'}), 200


@student_bp.delete('/<int:student_id>')
def delete_student(student_id: int):
    student_service.delete_student(student_id)
    return jsonify({'message': 'deleted'}), 200
