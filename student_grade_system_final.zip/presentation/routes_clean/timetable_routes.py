from __future__ import annotations

from flask import Blueprint, render_template

from business.timetable_service import TimetableService

timetable_bp = Blueprint('timetable_clean', __name__, url_prefix='/clean/timetable')
timetable_service = TimetableService()


@timetable_bp.get('/student')
def student_timetable():
    context = timetable_service.get_student_timetable_context()
    return render_template('timetable.html', **context)


@timetable_bp.get('/teacher')
def teacher_timetable():
    context = timetable_service.get_teacher_timetable_context()
    return render_template('timetable.html', **context)


@timetable_bp.get('/admin')
def admin_timetable():
    context = timetable_service.get_admin_timetable_context()
    return render_template('timetable.html', **context)
