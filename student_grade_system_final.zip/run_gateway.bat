@echo off
cd /d %~dp0
python api_gateway\gateway.py
pause
