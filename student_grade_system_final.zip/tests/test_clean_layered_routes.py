from pathlib import Path


def test_clean_routes_do_not_access_database_directly():
    clean_dir = Path('presentation/routes_clean')
    assert clean_dir.exists()
    forbidden = ['.query', 'db.session', 'Model.query']
    for py in clean_dir.glob('*.py'):
        text = py.read_text(encoding='utf-8')
        for token in forbidden:
            assert token not in text, f'{py} must not use {token} directly'


def test_app_clean_exists_as_layered_entry_point():
    app_clean = Path('app_clean.py')
    assert app_clean.exists()
    text = app_clean.read_text(encoding='utf-8')
    assert 'create_app' in text
    assert 'register_blueprint' in text
