import pytest
import importlib.util
from pathlib import Path


def load_gateway():
    path = Path(__file__).resolve().parents[1] / 'api_gateway' / 'gateway.py'
    spec = importlib.util.spec_from_file_location('gateway', path)
    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
    except ModuleNotFoundError as exc:
        pytest.skip(f"runtime dependency not installed: {exc}")
    return module


def test_gateway_requires_token_for_students():
    gateway = load_gateway()
    client = gateway.app.test_client()
    response = client.get('/api/students')
    assert response.status_code == 401


def test_gateway_has_health_route():
    gateway = load_gateway()
    rules = [str(r) for r in gateway.app.url_map.iter_rules()]
    assert '/health' in rules
