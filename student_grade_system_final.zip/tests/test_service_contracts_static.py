from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_required_docs_exist():
    required = [
        'docs/01_REQUIREMENTS_ASR_QLSV.md',
        'docs/02_LAYERED_ARCHITECTURE_QLSV.md',
        'docs/03_SERVICE_CONTRACTS_QLSV.md',
        'docs/11_ATAM_TRADEOFFS_QLSV.md',
        'docs/diagrams/use_case_qlsv.drawio',
        'docs/diagrams/component_layered_qlsv.drawio',
        'docs/diagrams/deployment_qlsv.drawio',
    ]
    for item in required:
        assert (ROOT / item).exists(), item


def test_microservices_exist():
    for svc in ['auth_service','student_service','teacher_service','grade_service','enrollment_service','timetable_service','notification_service']:
        assert (ROOT / 'microservices' / svc / 'app.py').exists(), svc
