from pathlib import Path


def test_legacy_monolith_removed_from_default_source_tree():
    assert not Path('presentation/routes/legacy_monolith.py').exists()


def test_app_py_has_no_legacy_fallback():
    text = Path('app.py').read_text(encoding='utf-8')
    forbidden = ['QLSV_USE_LEGACY', 'legacy_monolith', 'presentation.routes.legacy_monolith']
    for token in forbidden:
        assert token not in text


def test_app_clean_is_only_bootstrap_and_no_database_access():
    text = Path('app_clean.py').read_text(encoding='utf-8')
    assert 'create_app' in text
    assert 'CLEAN_BLUEPRINTS' in text
    assert '.query' not in text
    assert 'db.session' not in text


def test_all_clean_routes_obey_controller_service_repository_rule():
    clean_dir = Path('presentation/routes_clean')
    forbidden = ['.query', 'db.session', 'Model.query']
    for py in clean_dir.glob('*.py'):
        text = py.read_text(encoding='utf-8')
        for token in forbidden:
            assert token not in text, f'{py} must not use {token} directly'
